#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 25

void gotoxy(int x,int y)
{
    printf("%c[%d;%df",0x1B,y,x);
}
int x,y;
void menu(){  
 	gotoxy(15,4);
	printf("*************************************************");
	y=4;
	for(x=0;x<8;x++){
		gotoxy(15,y++);
		printf("*");
	}
	y=4;
	for(x=0;x<8;x++){
		gotoxy(63,y++);
		printf("*");
	}
	gotoxy(15,12);
	printf("*************************************************");
	
	gotoxy(25,5);printf("Operaciones disponibles");
    gotoxy(18,7);printf("1.- Contactar con el especialista");
    gotoxy(18,8);printf("2.- Ver medicamentos");
    gotoxy(18,9);printf("3.- Salir");
	 
}


int main(){
	int solicitud,x=1;
	
	do{
	system("clear");
	menu();
	gotoxy(18,11);printf("Seleccion: ");
    	scanf("%i",&solicitud);
    	while(solicitud<1 || solicitud>3){
    	gotoxy(35,11);printf("Operacion no existente");
    	gotoxy(27,11);printf("     ");
    	gotoxy(18,11);printf("Seleccion: ");
    	scanf("%i",&solicitud);
	}
		switch (solicitud){
				case 1:
					system("clear");
					system("./proceso2");
					break;
				case 2: 
					system("crear");
					break;
				case 4:
					x=2;
					break;
	
		}
	}while(x!=2);	
}
